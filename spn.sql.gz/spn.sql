-- phpMyAdmin SQL Dump
-- version 3.3.7deb3build0.10.10.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 25, 2011 at 09:21 AM
-- Server version: 5.1.49
-- PHP Version: 5.3.3-1ubuntu9.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `spn`
--

-- --------------------------------------------------------

--
-- Table structure for table `hsh_contents`
--

DROP TABLE IF EXISTS `hsh_contents`;
CREATE TABLE IF NOT EXISTS `hsh_contents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `created_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `hsh_contents`
--

INSERT INTO `hsh_contents` (`id`, `title`, `url`, `content`, `created_by`) VALUES
(1, 'vvvv', '', '', 0),
(2, 'sss', 'sss', '', 0),
(3, 'aaaaaaaa', '', '', 0),
(4, 'fffffff', 'souphorntest.html', 'This is my content', 0);

-- --------------------------------------------------------

--
-- Table structure for table `hsh_users`
--

DROP TABLE IF EXISTS `hsh_users`;
CREATE TABLE IF NOT EXISTS `hsh_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_shortcut` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `pwd` varchar(255) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `created` date DEFAULT NULL,
  `last_modified` date DEFAULT NULL,
  `su` int(11) DEFAULT '0',
  `email` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `hsh_users`
--

INSERT INTO `hsh_users` (`id`, `user_shortcut`, `name`, `username`, `pwd`, `status`, `created`, `last_modified`, `su`, `email`) VALUES
(1, 'spn', 'Administrator', 'souphorn', '*791EB9C8ABB1348CD13618F75F52EB2C6B61A086', NULL, NULL, NULL, 1, 'ansouphorn@gmail.com');
