-- phpMyAdmin SQL Dump
-- version 3.3.7deb3build0.10.10.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 25, 2011 at 07:52 PM
-- Server version: 5.1.49
-- PHP Version: 5.3.3-1ubuntu9.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `spn`
--

-- --------------------------------------------------------

--
-- Table structure for table `hsh_contents`
--

DROP TABLE IF EXISTS `hsh_contents`;
CREATE TABLE IF NOT EXISTS `hsh_contents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` mediumtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `url` varchar(255) CHARACTER SET utf8 NOT NULL,
  `content` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `created_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `hsh_contents`
--

INSERT INTO `hsh_contents` (`id`, `title`, `url`, `content`, `created_by`) VALUES
(9, 'កីឡា', 'កីឡា', '', 0),
(10, 'បាល់ទាត់', 'បាល់ទាត់', 'បើ​រំលឹក​ពី​កីឡា​បាល់ទាត់ World Cup 2010 នៅ​ប្រទេស​អាហ៊្រិក​ខាង​ត្បូង​អ្នក​ទាំង​អស់​គ្នា​ប្រហែល​នៅ​ចាំ​គ្រូ​ទាយ​ ម្នាក់​ជនជាតិ​អាហ្លឺម៉ង់​ជា​មិន​ខាន នោះ​គឺ​ត្រី​មឹក​មួយ​ដែល​មាន​ឈ្មោះ​ថា “ Paul” ប៉ុន្តែ​ចាប់​ពី​ថ្ងៃ​នេះ​ទៅ​យើង​លែង​បាន​ឃើញ​រូបគាត់​ក្នុង​សារព័តិមាន​ទៀត ហើយ​ ដោយ​សារ​តែ​រូបគាត់​ទើប​តែ​ទទួល​មរណភាព​នៅ​ថ្ងៃ​នេះនៅ​ក្នុង​មជ្ឈមណ្ឌល Sea Life Center នៅ Oberhausen នៃ​ប្រទេស​អាហ្លឺម៉ង់។', 0),
(11, 'ដាក់​ Facebook របស់​អ្នក​លើ​ Desktop', 'ដាក់Facebook', 'ប្រសិន​ជា​អ្នក​មាន​កំព្យួទ័រ​ ដែល​ភ្ជាប់​អ៊ីនធើណេត​ប្រើប្រាស់​ផ្ទាល់​ខ្លួន ហើយ​អ្នក​ប្រើ Facebook ហើយ​អ្នក​ចង់​មាន​កម្មវិធី​មួយ ​ដែល​អាច​​ប្រាប់​អ្នក​បាន​អំពី​សកម្មភាព​ទាំងឡាយ​ដែល មិត្តភក្តិ​របស់​អ្នក​កំពុង​តែ​ធ្វើ​ក្នុង​ Facebook ដូច​ជា ការ​ប្រកាស​ថ្មី​ៗ​ ការ​អញ្ជើញ​អ្នក​ធ្វើ​ជា​មិត្តភក្តិ សារផ្ញើរ​មក​កាន់​អ្នកជាដើម ដោយ​អ្នក​មិន​ចាំបាច់​បើក​គេហទំព័រ​ Facebook នោះ​ អ្នក​អាច​ធ្វើ​វា​បាន​ដោយ​គ្រាន់​តែ​ Download កម្មវិធី​នោះ​ដាក់​ក្នុង​កំព្យួទ័រ​របស់​អ្នក​នោះ​ជា​ការ​ស្រេច។ ដូច្នេះ​គ្រប់​សកម្មភាព​ទាំង​ឡាយ​របស់​មិត្តភក្តិ​របស់​អ្នក ដូច​ដែល​ខ្ញុំ​បាន​រៀបរាប់​ខាង​លើនឹង​លោត​ចេញ​ប្រាប់​អ្នក ​អំពី​អ្វី​ដែល​ពួក​គេ​បាន​កំពុង​តែ​ធ្វើដូច​រូប ខាងក្រោមបង្ហាញ។ កម្មវីធី​នេះ​អាច​ប្រើ​បាន​ទាំង Windows និង Mac។', 0);

-- --------------------------------------------------------

--
-- Table structure for table `hsh_users`
--

DROP TABLE IF EXISTS `hsh_users`;
CREATE TABLE IF NOT EXISTS `hsh_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_shortcut` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `pwd` varchar(255) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `created` date DEFAULT NULL,
  `last_modified` date DEFAULT NULL,
  `su` int(11) DEFAULT '0',
  `email` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `hsh_users`
--

INSERT INTO `hsh_users` (`id`, `user_shortcut`, `name`, `username`, `pwd`, `status`, `created`, `last_modified`, `su`, `email`) VALUES
(1, 'spn', 'Administrator', 'souphorn', '*791EB9C8ABB1348CD13618F75F52EB2C6B61A086', NULL, NULL, NULL, 1, 'ansouphorn@gmail.com');
